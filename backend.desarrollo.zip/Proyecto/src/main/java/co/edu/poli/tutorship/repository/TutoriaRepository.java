package co.edu.poli.tutorship.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import co.edu.poli.tutorship.model.Tutoria;

public interface TutoriaRepository extends JpaRepository<Tutoria, Integer> {

}
