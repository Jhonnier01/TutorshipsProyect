package co.edu.poli.tutorship.services;

import org.springframework.stereotype.Service;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;

import co.edu.poli.tutorship.model.SMS;



@Service
public class SMSServiceTwilio implements SMSService{
	
    // Find your Account Sid and Token at twilio.com/console
    public static final String ACCOUNT_SID = "AC5704db4b32c67a930c8f79f0b308d03d";
    public static final String AUTH_TOKEN = "ab9a224cb3df064385cef5782fdcc91e";

    @Override
    public Message sendSMS(SMS sms) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);// JEROKO NUBE GRATIS JEROKO
        Message message = Message.creator(
                new com.twilio.type.PhoneNumber(sms.getPhoneNumberTo()),
                new com.twilio.type.PhoneNumber("+573202650433"),//The Twilio phone number
                sms.getBody())
           .create();

        return message;
    }
    
}

