package co.edu.poli.tutorship.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import co.edu.poli.tutorship.model.Ubicacion;

public interface UbicacionRepository extends JpaRepository<Ubicacion, Integer> {

}
